<html>

<body>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
<link rel="stylesheet" href="https://ebayoutsource.co.uk/assets/css/external/bootstrap-3-3-7.min.css">
<link rel="stylesheet" href="https://ebayoutsource.co.uk/assets/css/external/blue-light.css">
<style>
	:root { --primary-color: #002FC7 !important; } .col-box-title { background-image: url("https://ebayoutsource.co.uk/assets/images/demo/photo_main_banner.jpg"); }
</style>
<div id="template-container">
	<nav class="navbar">
		<div class="container-fluid">
			<div class="row navbar-top">
				<div class="col-xs-12 col-md-6 navbar-header">
					<img class="logo img-fluid" alt="Brand" src="https://i.ebayimg.com/00/s/NDAyWDE2MDA=/z/migAAOSw7O9e3wpw/$_45.PNG" width="auto" height="120">
				</div>
				<div class="col-xs-12 col-md-6 navbar-best">
					<div class="col-md-6">
						<p><i class="fa fa-star"></i> UK Seller</p>
					</div>
					<div class="col-md-6">
						<p><i class="fa fa-truck"></i> Fast Shipping</p>
					</div>
					<div class="col-md-6">
						<p><i class="fa fa-thumbs-up"></i> Greater Service</p>
					</div>
					<div class="col-md-6">
						<p><i class="fa fa-heart"></i> Satisfaction Guarantee</p>
					</div>
				</div>
			</div>
			<div class="row menu">
				<div class="col-xs-12">
					<ul class="nav navbar-nav">
						<li><a class="text-uppercase" href="https://www.ebay.co.uk/sch/fashionaid/m.html?_nkw=&_armrs=1&_ipg=&_from=" target="_blank">Our Products</a>
						</li>
						<li><a class="text-uppercase" href="https://www.ebay.co.uk/usr/fashionaid" target="_blank">Like Our Page</a>
						</li>
						<li><a class="text-uppercase" href="https://www.ebay.co.uk/fdbk/feedback_profile/fashionaid?filter=feedback_page:All&_trksid=p2545226.m2531.l4585" target="_blank">Check Our Feedback</a>
						</li>
						<li><a class="text-uppercase" href="https://contact.ebay.co.uk/ws/eBayISAPI.dll?FindAnswers&requested=fashionaid&_trksid=p2545226.m2531.l4583&rt=nc" target="_blank">Contact Us</a>
						</li>
					</ul>
				</div>
			</div>
		</div>
	</nav>
	<div class="container-fluid bg-texture">
		<div class="row">
			<div class="col-xs-12 col-sm-10 col-sm-offset-1">
				<div class="col-xs-12"></div>
			</div>
		</div>
		<div class="row">
			<div class="col-xs-12 col-sm-7 col-sm-offset-1 ">
				<div class="col-xs-12 col-box">
					<div class="col-xs-12 mt-0">
						<div class="display-4">{{$name}}</div>
					</div>
				</div>
				<div class="col-xs-12 col-box">
					<div class="col-xs-12 col-box-header">
						<h4 class="text-uppercase">gallery</h4>
					</div>
					<div class="col-xs-12 col-box-inside">
						<div id="gall">
							@isset($images[0])
								<input id="pic_0" name="switch" type="radio" checked>
								<label for="pic_0">
									<img src="{{$images[0]}}">
								</label>
								<img src="{{$images[0]}}">
							@endisset
							@isset($images[1])
								<input id="pic_1" name="switch" type="radio">
								<label for="pic_1">
									<img src="{{$images[1]}}">
								</label>
								<img src="{{$images[1]}}">
							@endisset
							@isset($images[2])
								<input id="pic_2" name="switch" type="radio">
								<label for="pic_2">
									<img src="{{$images[2]}}">
								</label>
								<img src="{{$images[2]}}">
							@endisset
							@isset($images[3])
								<input id="pic_3" name="switch" type="radio">
								<label for="pic_3">
									<img src="{{$images[3]}}">
								</label>
								<img src="{{$images[3]}}">
							@endisset
							@isset($images[4])
								<input id="pic_4" name="switch" type="radio">
								<label for="pic_4">
									<img src="{{$images[4]}}">
								</label>
								<img src="{{$images[4]}}">
							@endisset
						</div>
						<div class="line-break line-break-4"><span></span>
						</div>
						<div class="clearfix"><span></span>
						</div>
					</div>
				</div>
				<div class="col-xs-12 col-box">
					<div class="col-xs-12 col-box-header">
						<h4 class="text-uppercase">description</h4>
					</div>
					<div class="col-xs-12 col-box-inside">
						<p><span style="font-size: 14.4px;">{!! $description !!}</span>
							<br>
						</p>
					</div>
				</div>
				<div id="tab-section" class="col-xs-12 col-box col-box-tab">
					<div class="tab-box col-box-inside">
						<input id="tab1" type="radio" name="tabs" checked="" class="text-uppercase">
						<label for="tab1" class="text-uppercase"><i class="fa fas fa-credit-card" aria-hidden="true"></i> Payment</label>
						<input id="tab2" type="radio" name="tabs" class="text-uppercase">
						<label for="tab2" class="text-uppercase"><i class="fa fas fa-truck"></i> Delivery</label>
						<input id="tab3" type="radio" name="tabs" class="text-uppercase">
						<label for="tab3" class="text-uppercase"><i class="fa fas fa-sync"></i> Return Policy</label>
						<section id="content-1">
							<div class="animation opacity inner-box">
								<div><span style="font-size: 14.4px;">We currently accept </span>PayPal<span style="font-size: 14.4px;"> payment methods</span>
								</div>
								<div>
									<br>
								</div>
								<div><span style="font-size: 14.4px;">We do not accept paper cheques or postal orders. </span>Payment must be received within 7 days. To ensure your purchase is protected by the eBay Protection Scheme it will only be delivered to your registered PayPal/ eBay address.</div>
								<div class="box-logo">
									<img src="https://ebayoutsource.co.uk/assets/images/brands/paypal_logo.png">
									<img src="https://ebayoutsource.co.uk/assets/images/brands/visa_logo_small.png">
									<img src="https://ebayoutsource.co.uk/assets/images/brands/master_card_logo_small.png">
									<img src="https://ebayoutsource.co.uk/assets/images/brands/discover_logo_small.png">
									<img src="https://ebayoutsource.co.uk/assets/images/brands/american_express_logo_small.png">
								</div>
							</div>
						</section>
						<section id="content-2">
							<div class="animation opacity inner-box">
								<p><span style="font-size: 14.4px;">All eligible items are dispatched through Royal Mail within 24 hours of receiving cleared funds. Items are carefully & professionally wrapped, so you receive your item in perfect condition. Items bought over the weekends and Bank Holidays will be dispatched on the 1st postal day.</span>
								</p>
								<p><span style="font-size: 14.4px;">Items should be received within 2-3 working days. In the unlikely event that you do not receive your item within this time, please allow 10 working days for delivery before contacting us, as the Royal Mail do not consider an item lost before that time (15 days for international).</span>
								</p>
							</div>
						</section>
						<section id="content-3">
							<div class="animation opacity inner-box">
								<p><span style="font-size: 14.4px;">In the event of Returns, Simply send it back to us within 14 days of receiving it in its original packaging, unused and unworn condition and we will issue a full refund once we receive the item(s).</span>
								</p>
								<p><span style="font-size: 14.4px;">However, please contact us with the details if an exchange is needed and we will be more than happy to do so.</span>
								</p>
							</div>
						</section>
					</div>
				</div>
				<div id="cross-section" class="col-xs-12 col-box">
					<div class="col-xs-12 col-box-header">
						<h4 class="text-uppercase"> Other Products </h4>
					</div>
					<div class="col-xs-12 col-box-inside">
						<div class="col-xs-12 col-sm-6 col-md-3">
							<img class="img-responsive" src="https://i.ebayimg.com/images/g/nsUAAOSwa3tfLw4j/s-l1600.jpg">
							<h4>DIESEL J SABORU PALM Mens Hoodie Jacket Palm Leaf Print Casual White Hooded Coat</h4><a class="button" target="_blank" href="https://www.ebay.co.uk/itm/143677999155">SEE</a>
						</div>
						<div class="col-xs-12 col-sm-6 col-md-3">
							<img class="img-responsive" src="https://i.ebayimg.com/images/g/y7wAAOSwkgZfMEEA/s-l1600.jpg">
							<h4>DIESEL Mens Puffer Jacket Padded Down Fill Quilted Casual Winter Warm Outwear Coat</h4><a class="button" target="_blank" href="https://www.ebay.co.uk/itm/143678680014">SEE</a>
						</div>
						<div class="col-xs-12 col-sm-6 col-md-3">
							<img class="img-responsive" src="https://i.ebayimg.com/images/g/atgAAOSwlbVfMuM4/s-l1600.jpg">
							<h4>DIESEL T DIEGO HE Mens T-Shirt Crew Neck Short Sleeve Casual Black Summer Tee</h4><a class="button" target="_blank" href="https://www.ebay.co.uk/itm/143680318447">SEE</a>
						</div>
						<div class="col-xs-12 col-sm-6 col-md-3">
							<img class="img-responsive" src="https://i.ebayimg.com/images/g/HpsAAOSwjFVfNBfv/s-l1600.jpg">
							<h4>JUST CAVALLI S01GC0575 Mens T Shirt Crew Neck Tops Short Sleeve Cotton White Tee</h4><a class="button" target="_blank" href="https://www.ebay.co.uk/itm/143681076211">SEE</a>
						</div>
					</div>
				</div>
			</div>
			<div class="col-xs-12 col-sm-3">
				<div class="col-xs-12 col-box">
					<div class="col-xs-12 mt-0"></div>
				</div>
				<div class="col-xs-12 col-box">
					<div class="col-xs-12 col-box-header mt-3">
						<h4 class="text-uppercase text-center">feedback</h4>
					</div>
					<div class="col-xs-12 col-box-inside col-centered">
						<h3>150+</h3>
						<div class="col-feedback-stars"><i class="fa fas fa-star" aria-hidden="true"></i><i class="fa fas fa-star" aria-hidden="true"></i><i class="fas fas fa-star" aria-hidden="true"></i><i class="fa fas fa-star" aria-hidden="true"></i><i class="fa fas fa-star" aria-hidden="true"></i>
						</div>
						<h6 class="text-uppercase">positive comments</h6>
						<hr>
						<ul class="feedback-example-comment-list">
							<li><span class="buyer-id">6***r</span>: Great service and fast delivery</li>
							<li><span class="buyer-id">_***x</span>: Perfect Thank you : ) I will come again soon: )</li>
							<li><span class="buyer-id">a***a</span>: Thanks. Highly recommended</li>
							<li><span class="buyer-id">b***v</span>: Easy purchase and honest would recommend,came as described.</li>
							<li><span class="buyer-id">c***p</span>: Really pleased. Absolutely superb</li>
							<li><span class="buyer-id">4***r</span>: Ultra fast delivery! Perfect item as described</li>
						</ul>
						<p><a href="https://feedback.ebay.co.uk/ws/eBayISAPI.dll?ViewFeedback2&userid=fashionaid" target="_blank">SEE ALL FEEDBACK</a>
						</p>
					</div>
				</div>
				<div class="col-xs-12 col-box">
					<div class="col-xs-12 col-box-header">
						<h4 class="text-uppercase text-center"> Delivery</h4>
					</div>
					<div class="col-xs-12 col-box-inside ">
						<div class="delivery-logos-box">
							<img src="https://ebayoutsource.co.uk/assets/images/brands/USPS-logo-small.png">
							<img src="https://ebayoutsource.co.uk/assets/images/brands/ups_logo_small.png">
							<img src="https://ebayoutsource.co.uk/assets/images/brands/deutsche_post_logo_small.png">
							<img src="https://ebayoutsource.co.uk/assets/images/brands/gls_logo_small.png">
							<img src="https://ebayoutsource.co.uk/assets/images/brands/australia_post_logo_small.png">
							<img src="https://ebayoutsource.co.uk/assets/images/brands/logo-royal-mail.png">
						</div>
						<ul class="delivery-list-payment"></ul>
					</div>
				</div>
				<div id="col-why-us" class="col-xs-12 col-box">
					<div class="col-xs-12 col-box-header">
						<h4 class="text-uppercase text-center">Why us</h4>
					</div>
					<div class="col-xs-12 col-box-inside">
						<p>We are always looking for the best suppliers, in order to provide our customers with the highest quality items and best deals to be found on the internet. As much as our customers love our items and service, we"re always open to suggestions on how to improve things. if there"s something you think we could be doing better, then don"t hesitate to let us know.
							<br>
						</p>
					</div>
				</div>
				<div class="col-xs-12 col-box">
					<div class="col-xs-12 col-box-header">
						<h4 class="text-uppercase text-center">Category</h4>
					</div>
					<div class="col-xs-12 col-box-inside category-box">
						<ul>
							<li><a href="https://www.ebay.co.uk/str/fashionaid/All-Brands/_i.html?_storecat=3818085419" target="_blank">Featured Brands</a>
							</li>
							<li><a href="https://www.ebay.co.uk/str/fashionaid/Mens/_i.html?_storecat=3818085519" target="_blank">Shop For Man</a>
							</li>
							<li><a href="https://www.ebay.co.uk/str/fashionaid/Womens/_i.html?_storecat=3818085619" target="_blank">Shop For Woman</a>
							</li>
							<li><a href="https://www.ebay.co.uk/str/fashionaid/Kids/_i.html?_storecat=3818085719" target="_blank">Shop For Kids</a>
							</li>
							<li><a href="https://www.ebay.co.uk/str/fashionaid?rt=nc&_oac=1" target="_blank">Our Products</a>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="container-fluid container-footer">
		<footer>
			<div class="row">
				<div class="col-xs-12">
					<div class="col-xs-12 col-md-4">
						<h3 class="text-uppercase">About us</h3>
						<p><span style="font-size: 14.4px;">We are a small family run business based in the UK. The idea is to serve the customers with the best quality fashion clothing s which covers modern trends. Our customers are our topmost priority. Feedback from you will help us grow as a business.</span>
							<br>
						</p>
					</div>
					<div class="col-xs-12 col-md-4">
						<h3 class="text-uppercase">Benefits</h3>
						<ul class="delivery-list-payment benefits-list-payment">
							<li>Only High Product Quality</li>
							<li>Best Prices</li>
							<li>Shipping with Royal Mail</li>
							<li>Original Product Guaranteed</li>
						</ul>
					</div>
					<div class="col-xs-12 col-md-4 footer-uselink-box">
						<h3 class="text-uppercase">Useful Links</h3>
						<ul>
							<li><a target="_blank" class="text-uppercase" href="https://www.ebay.co.uk/usr/fashionaid">Returns</a>
							</li>
							<li><a target="_blank" class="text-uppercase" href="https://www.ebay.co.uk/fdbk/feedback_profile/fashionaid?filter=feedback_page:All&_trksid=p2545226.m2531.l4585">Feedback</a>
							</li>
							<li><a target="_blank" class="text-uppercase" href="https://www.ebay.co.uk/usr/fashionaid">Business Details</a>
							</li>
						</ul>
					</div>
				</div>
			</div>
			<div class="row ">
				<div class="col-md-8 col-md-offset-2 col-footer-copy">
					<p class="text-uppercase footer-last-p">Copyright © 2020 fashionaid | Template by
						<a href="https://www.ebay.com/str/combosoft" target="_blank"></a>
					</p>
				</div>
			</div>
		</footer>
	</div>
</div>
</body>

</html>