<!doctype html>
<html class="no-js" lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="https://ebayoutsource.co.uk/assets/css/external/purple-storm.css">
	<link rel="stylesheet" href="https://ebayoutsource.co.uk/assets/css/external/slider2.css">
	<style>
		:root { --primary-color: #800000 !important; }
		.col-box-header h4 {
			margin: 0;
			font-size: 18px;
			font-family: "Open Sans", sans-serif;
			font-weight: 700;
			background: var(--primary-color);
			color: #fff;
			width: 100%;
			padding: 12px 15px;
			text-transform: uppercase;
		}
		.col-centered ul li:first-child {
			border-top: none;
		}
		.col-centered ul li {
			border-bottom: none;
			margin: 8px 10px;
		}
		.see-all-feedback{
			margin-top: 14px;
    		margin-bottom: 8px;
		}
		.see-all-feedback a:hover{
			text-decoration: underline;
		}
		@media (max-width: 767px){
			.m-dv{
				display: flex;
				flex-direction: column-reverse;
			}
		}
		@media(max-width: 767px){
			#m-d-tab{
				display: none;
			}
		}
		@media(min-width: 768px){
			#d-d-tab{
				display: none;
			}
		}

		.tabarea input:checked+label {
			color: #fff;
			border-bottom: 0;
			background: var(--primary-color);
			padding-bottom: 10px;
		}

		#m_tab1:checked~#m_content1,
		#m_tab2:checked~#m_content2,
		#m_tab3:checked~#m_content3,
		#m_tab4:checked~#m_content4 {
			display: inline-block;
		}

		.col-box {
			margin: 0 0 15px 0;
		}

		.col-box {
			margin: 0 0 15px 0;
		}

		.col-box-tab {
			margin-top: 40px;
		}

		.col-box-header {
			background: var(--primary-color);
			color: #fff;
		}

		.col-box-inside {
			padding-top: 5px;
			padding-bottom: 5px;
			border: 1px solid #ccc;
		}

		#cross-section .col-box-inside div {
			padding: 8px;
			margin: 8px 0;
			text-align: center;
			border-right: 1px solid #eee;
		}

		#cross-section .col-box-inside div:last-child,
		#cross-section .col-box-inside .no-border-right {
			border-right: 0;
		}


		/* Small devices (tablets, 768px and up) */

		@media (max-width: 992px) {
			#cross-section .col-box-inside div:nth-of-type(2) {
				border-right: 0;
			}
		}

		.col-box-title {
			color: #fff;
			background: var(--primary-color);
			padding: 30px;
			text-align: center;
			margin-top: 30px;
			margin-bottom: 30px;
			background-image: url("https://test1.jpg");
			background-position: center center;
		}

		.col-box-title h1 {
			font-weight: 700;
			font-size: 38px;
		}

		#col-why-us .col-box-inside {
			padding-top: 10px;
		}

		.col-box-header {
			background: var(--primary-color);
			color: #fff;
		}

		.col-box-inside {
			padding-top: 5px;
			padding-bottom: 5px;
			border: 1px solid #ccc;
		}

		#cross-section .col-box-inside div {
			padding: 8px;
			margin: 8px 0;
			text-align: center;
			border-right: 1px solid #eee;
		}

		#cross-section .col-box-inside div:last-child,
		#cross-section .col-box-inside .no-border-right {
			border-right: 0;
		}


		/* Small devices (tablets, 768px and up) */

		@media (max-width: 992px) {
			#cross-section .col-box-inside div:nth-of-type(2) {
				border-right: 0;
			}
		}


		/* Medium devices (desktops, 992px and up) */

		@media (max-width: 768px) {
			#cross-section>div {
				border-right: 0;
			}

			#cross-section>div:last-child {
				border-bottom: 0;
			}
		}

		#cross-section img {
			margin: auto auto 6px auto;
		}

		#col-why-us .col-box-inside {
			padding-top: 10px;
		}

		.col-centered {
			text-align: center;
		}

		.col-feedback-stars {
			color: #f2ba13;
			font-size: 20px;
			padding: 0px 5px 4px 5px;
		}

		.feedback-example-comment-list {
			list-style: none;
			padding: 0;
		}

		.feedback-example-comment-list li {
			padding-left: 1.3em;
			text-align: left;
			margin-top: 7px;
		}

		.feedback-example-comment-list li:before {
			content: "\f055";
			/* FontAwesome Unicode */
			font-family: "Font Awesome 5 Free";
			display: inline-block;
			margin-left: -1.3em;
			font-weight: 900;
			/* same as padding-left set on li */
			width: 1.3em;
			/* same as padding-left set on li */
			color: #5ebf3c;
		}

		.feedback-example-comment-list li .buyer-id {
			font-weight: 700;
		}

	</style>
</head>

<body>
	<div class="header-container">
		<div class="header-top">
			<div class="grid-container">
				<p><span>Welcome to Our Official eBay Store</span>
				</p>
			</div>
		</div>
	</div>
	<div id="header" class="o-panel o-panel--header">
		<div class="grid-container">
			<div class="grid-x grid-padding-x align-middle align-center c-header">
				<div class="cell">
					<a class="c-header__logo" href="#">
						<img class="logo img-fluid" alt="Brand" src="https://i.ebayimg.com/00/s/MTY5WDMxNg==/z/knAAAOSwghZdwK~-/$_7.GIF" width="auto" height="120">
					</a>
				</div>
			</div>
		</div>
	</div>
	<div class="header-container">
		<div class="header-content">
			<div class="grid-container">
				<div class="header-right">
					<input type="checkbox" id="nav-trigger" class="nav-trigger">
					<label for="nav-trigger" class="hidden-nav">MENU</label>
					<div class="menu-header menu-header-mobile">
						<div class="grid-container">
							<div class="menu-container">
								<ul class="menu">
									<li><a href="https://www.ebay.co.uk/str/topbrandoutletltd" target="_blank">Our Products</a>
									</li>
									<li><a href="https://www.ebay.co.uk/str/topbrandoutletltd#tab1" target="_blank">About Us</a>
									</li>
									<li><a href="https://www.ebay.co.uk/cnt/intermediatedFAQ?requested=topbrandoutlet-ltd&_trksid=p2545226.m2531.l4583&rt=nc" target="_blank">Contact Us</a>
									</li>
									<li><a href="https://www.ebay.co.uk/str/topbrandoutletltd" target="_blank">Visit Store</a>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="menu-header">
				<div class="grid-container">
					<div class="menu-container">
						<ul class="menu">
							<li><a href="https://www.ebay.co.uk/str/topbrandoutletltd" target="_blank">Our Products</a>
							</li>
							<li><a href="https://www.ebay.co.uk/usr/topbrandoutlet-ltd/" target="_blank">Like Our Page</a>
							</li>
							<li><a href="https://www.ebay.co.uk/fdbk/feedback_profile/topbrandoutlet-ltd?filter=feedback_page:All&_trksid=p2545226.m2531.l4585" target="_blank">Check Our Feedback</a>
							</li>
							<li><a href="https://www.ebay.co.uk/str/topbrandoutletltd#tab1" target="_blank">About us</a>
							</li>
							<li><a href="https://contact.ebay.co.uk/ws/eBayISAPI.dll?FindAnswers&requested=topbrandoutlet-ltd&_trksid=p2545226.m2531.l4583&rt=nc" target="_blank">Contact Us</a>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="promo hidden-sm hidden-xs">
		<div class="grid-container">
			<div class="promo-content"><span class="box-promotion"><i class="fa fa-star" aria-hidden="true"></i><span>UK Seller</span></span><span class="box-promotion"><i class="fa fa-truck" aria-hidden="true"></i><span>Fast Shipping</span></span><span class="box-promotion"><i class="fa fa-thumbs-up" aria-hidden="true"></i><span>Greater Service</span></span><span class="box-promotion"><i class="fa fa-heart" aria-hidden="true"></i><span>Satisfaction Guaranteed</span></span>
			</div>
		</div>
	</div>
	<div class="content">
		<div class="grid-container">
			<div class="grid-x grid-padding-x inner-row m-dv">
				<div class="cell small-order-1= medium-shrink hidden-xs hidden-sm left-content">
					<div class="hidden-xs hidden-sm">
						<div class="widget_box">

							<div class="list-group">
								<h2>Our Brands</h2>
								<div class="widget_content">
									<ul>
										<li><a href="https://www.ebay.co.uk/str/topbrandoutletltd/Abercrombie-Fitch/_i.html?store_cat=29836836016" target="_blank">Abercrombie & Fitch</a>
										</li>
										<li><a href="https://www.ebay.co.uk/str/topbrandoutletltd/Adidas/_i.html?store_cat=29127278016" target="_blank">Adidas</a>
										</li>
										<li><a href="https://www.ebay.co.uk/str/topbrandoutletltd/Armani/_i.html?store_cat=24379157016" target="_blank">Armani</a>
										</li>
										<li><a href="https://www.ebay.co.uk/str/topbrandoutletltd/Diesel/_i.html?store_cat=21437734016" target="_blank">Diesel</a>
										</li>
										<li><a href="https://www.ebay.co.uk/str/topbrandoutletltd/Ellesse/_i.html?store_cat=34450231016" target="_blank">Ellesse</a>
										</li>
										<li><a href="https://www.ebay.co.uk/str/topbrandoutletltd/Farah/_i.html?store_cat=24379158016" target="_blank">Farah</a>
										</li>
										<li><a href="https://www.ebay.co.uk/str/topbrandoutletltd/Just-Cavalli/_i.html?store_cat=35197507016" target="_blank">Just Cavalli</a>
										</li>
										<li><a href="https://www.ebay.co.uk/str/topbrandoutletltd/Levis/_i.html?store_cat=29312037016" target="_blank">Levi's</a>
										</li>
										<li><a href="https://www.ebay.co.uk/str/topbrandoutletltd/Nike/_i.html?store_cat=34474984016" target="_blank">Nike</a>
										</li>
										<li><a href="https://www.ebay.co.uk/str/topbrandoutletltd/True-Religion/_i.html?store_cat=35725353016" target="_blank">True Religion</a>
										</li>
										<li><a href="https://www.ebay.co.uk/str/topbrandoutletltd/Other-Brands/_i.html?store_cat=21438880016" target="_blank">Other Brands</a>
										</li>
									</ul>
								</div>
							</div>
							<br>
							<div class="col-xs-12 col-box">
								<div class="col-xs-12 col-box-header mt-3">
									<h4 class="text-uppercase text-center">feedback</h4>
								</div>
								<div class="col-xs-12 col-box-inside col-centered">
									<h3></h3>
									<div class="col-feedback-stars"><i class="fa fas fa-star" aria-hidden="true"></i><i class="fa fas fa-star" aria-hidden="true"></i><i class="fas fas fa-star" aria-hidden="true"></i><i class="fa fas fa-star" aria-hidden="true"></i><i class="fa fas fa-star" aria-hidden="true"></i>
									</div>
									<h6 class="text-uppercase">positive comments</h6>
									<hr>
									<ul class="feedback-example-comment-list">
										<li><span class="buyer-id">e***n</span>: Great purchase and early delivery! Thank you</li>
										<li><span class="buyer-id">j***1</span>: Great item, perfect, arrived quickly thank you</li>
										<li><span class="buyer-id">1***j</span>: Thanks for a smooth transaction. Excellent Ebayer.</li>
										<li><span class="buyer-id">p***l</span>: Happy with item and service</li>
										<li><span class="buyer-id">0***m</span>: A Recommended seller, great product.</li>
										<li><span class="buyer-id">a***3</span>: Item arrived 8 days early. Item as stated. Well impressed.</li>
									</ul>
									<p class="see-all-feedback">
										<a href="https://www.ebay.co.uk/fdbk/feedback_profile/topbrandoutlet-ltd?filter=feedback_page:All&_trksid=p2545226.m2531.l4585" target="_blank">SEE ALL FEEDBACK</a>
									</p>
								</div>
							</div>
							<div class="list-group">
								<h2>Quick Navigation</h2>
								<div class="widget_content">
									<ul>
										<li><a target="_blank" href="https://www.ebay.co.uk/cnt/intermediatedFAQ?requested=topbrandoutlet-ltd&_trksid=p2545226.m2531.l4583&rt=nc">Contact Us</a>
										</li>
										<li><a target="_blank" href="https://www.ebay.co.uk/fdbk/feedback_profile/topbrandoutlet-ltd?filter=feedback_page:All&_trksid=p2545226.m2531.l4585">Feedback</a>
										</li>
										<li><a target="_blank" href="https://www.ebay.co.uk/usr/topbrandoutlet-ltd">Business Details</a>
										</li>
										<li><a target="_blank" href="https://www.ebay.co.uk/str/topbrandoutletltd">Visit Our Shop</a>
										</li>
									</ul>
								</div>
							</div>
							<div class="list-group">
								<h2>Shipping Partner</h2>
								<div class="widget_content">
									<br>
									<img src="https://i.ibb.co/r3SnRGP/Royal-Mail-Logo.jpg">
								</div>
							</div>
						</div>
					</div>
					<div class="col-xs-12 col-sm-3">
						<div class="col-xs-12 col-box">
							<div class="col-xs-12 mt-0"></div>
						</div>
					</div>

					<div class="tabarea" id="d-d-tab">
						<div class="tab-content">
							<input id="m_tab1" type="radio" name="m_tabs" checked>
							<label for="m_tab1"><span>Returns</span>
							</label>
							<section id="m_content1">
								<p>In the event of Returns, Simply send it back to us within 14 days of receiving it in its original packaging, unused and unworn condition and we will issue a full refund once we receive the item(s).</p>
								<p>However, please contact us with the details if an exchange is needed and we will be more than happy to do so.</p>
							</section>
							<input id="m_tab2" type="radio" name="m_tabs">
							<label for="m_tab2"><span>Delivery</span>
							</label>
							<section id="m_content2">
								<p>All eligible items are dispatched through Royal Mail within 24 hours of receiving cleared funds. Items are carefully & professionally wrapped, so you receive your item in perfect condition. Items bought over the weekends and Bank Holidays will be dispatched on the 1st postal day.
								Items should be received within 2-3 working days. In the unlikely event that you do not receive your item within this time, please allow 10 working days for delivery before contacting us, as the Royal Mail do not consider an item lost before that time (15 days for international).
									<br>
								</p>
								<!-- <p>All eligible items are dispatched through Royal Mail within 24 hours of receiving cleared funds. Items are carefully & professionally wrapped, so you receive your item in perfect condition. Items bought over the weekends and Bank Holidays will be dispatched on the 1st postal day.</p>
								<p>Items should be received within 2-3 working days. In the unlikely event that you do not receive your item within this time, please allow 10 working days for delivery before contacting us, as the Royal Mail do not consider an item lost before that time (15 days for international).<p/> -->
							</section>
							<input id="m_tab3" type="radio" name="m_tabs">
							<label for="m_tab3"><span>Payment</span>
							</label>
							<section id="m_content3">You can make your payment through eBay Payment gateway.</section>
							<input id="m_tab4" type="radio" name="m_tabs">
							<label for="m_tab4"><span>About Us</span>
							</label>
							<section id="m_content4">
								<p>Our eBay store is a small family-run business, where we still put our customers first. We are always looking for the best suppliers, in order to provide our customers with the highest quality items and best deals to be found on the internet.</p>
							</section>
						</div>
					</div>

				</div>
				<div class="cell medium-auto right-content">
					<h1 class="title-heading d-v" style="text-align: center;"> {{$name}}</h1>
					<!--Item Title-->
					<div class="panel panel-default d-v">
						<div class="image-gallery">
							<div class="slider">
								@isset($images[0])
									<input type="radio" name="slide_switch" id="id_0" checked>
									<label for="id_0">
										<img src="{{$images[0]}}" width="100">
									</label>
									<div>
									<img src="{{$images[0]}}">
									</div>
								@endisset
								@isset($images[1])
									<input type="radio" name="slide_switch" id="id_1">
									<label for="id_1">
										<img src="{{$images[1]}}" width="100">
									</label>
									<div>
										<img src="{{$images[1]}}">
									</div>
								@endisset
								@isset($images[2])
									<input type="radio" name="slide_switch" id="id_2">
									<label for="id_2">
										<img src="{{$images[2]}}" width="100">
									</label>
									<div>
										<img src="{{$images[2]}}">
									</div>
								@endisset
								@isset($images[3])
									<input type="radio" name="slide_switch" id="id_3">
									<label for="id_3">
										<img src="{{$images[3]}}" width="100">
									</label>
									<div>
										<img src="{{$images[3]}}">
									</div>
								@endisset
								@isset($images[4])
									<input type="radio" name="slide_switch" id="id_4">
									<label for="id_4">
										<img src="{{$images[4]}}" width="100">
									</label>
									<div>
										<img src="{{$images[4]}}">
									</div>
								@endisset
							</div>
						</div>
					</div>
					<div class="panel panel-default desc-box d-v">
						<div class="panel-heading">DESCRIPTION</div>
						<div class="text-section">
							<div class="panel-body" vocab="https://schema.org/" typeof="Product"><span property="description">
							<div <br><p>{!! $description !!}</p><br>
							</div>
						</div>
					</div>
				</div>
				<br>
				<br>
				<div class="tabarea" id="m-d-tab">
					<div class="tab-content">
						<input id="tab1" type="radio" name="tabs" checked="">
						<label for="tab1"><span>Returns</span>
						</label>
						<section id="content1">
							<p>In the event of Returns, Simply send it back to us within 14 days of receiving it in its original packaging, unused and unworn condition and we will issue a full refund once we receive the item(s).</p>
							<p>However, please contact us with the details if an exchange is needed and we will be more than happy to do so.</p>
						</section>
						<input id="tab2" type="radio" name="tabs">
						<label for="tab2"><span>Delivery</span>
						</label>
						<section id="content2">
							<p>All eligible items are dispatched through Royal Mail within 24 hours of receiving cleared funds. Items are carefully & professionally wrapped, so you receive your item in perfect condition. Items bought over the weekends and Bank Holidays will be dispatched on the 1st postal day.</p>
							<p>Items should be received within 2-3 working days. In the unlikely event that you do not receive your item within this time, please allow 10 working days for delivery before contacting us, as the Royal Mail do not consider an item lost before that time (15 days for international).<p/>
						</section>
						<input id="tab3" type="radio" name="tabs">
						<label for="tab3"><span>Payment</span>
						</label>
						<section id="content3">You can make your payment through eBay Payment gateway.</section>
						<input id="tab4" type="radio" name="tabs">
						<label for="tab4"><span>About Us</span>
						</label>
						<section id="content4">
							<p>Our eBay store is a small family-run business, where we still put our customers first. We are always looking for the best suppliers, in order to provide our customers with the highest quality items and best deals to be found on the internet.</p>
						</section>
					</div>
				</div>
			</div>
		</div>
	</div>
	</div>
	<div class="footer">
		<div class="grid-container">
			<div class="grid-x grid-padding-x">
				<div class="cell small-24 medium-5 contact-us">
					<div class="head">About Us</div>
					<p>Our eBay store is a small family-run business, where we still put our customers first. We are always looking for the best suppliers, in order to provide our customers with the highest quality items and best deals to be found on the internet.</p>
				</div>
				<div class="cell small-24 medium-5 footer-signup">
					<div class="head">Newsletter</div>
					<p>Sign up to our newsletter for special deals</p><a href="https://www.ebay.co.uk/usr/topbrandoutlet-ltd" target="_blank" title="SUBMIT">SUBMIT</a>
				</div>
				<div class="cell small-24 medium-2 hidden-xs footer-promo">
					<div class="head">We Accept Only</div>
					<p>
						<img src="https://ebayoutsource.co.uk/assets/images/brands/visa_logo_small.png">
						<img src="https://ebayoutsource.co.uk/assets/images/brands/master_card_logo_small.png">
						<img src="https://ebayoutsource.co.uk/assets/images/brands/discover_logo_small.png">
						<img src="https://ebayoutsource.co.uk/assets/images/brands/american_express_logo_small.png">
					</p>
				</div>
				<div class="cell copyrights">
					<p class="text-center">© Copyright 2021 - Top Brand Outlet Ltd
						<br>(Template by
						<a class="footer_credit" href="https://www.ebay.co.uk/str/combosoft" target="_blank"></a>)</p>
				</div>
			</div>
		</div>
	</div>
</body>

</html>
</body>

</html>