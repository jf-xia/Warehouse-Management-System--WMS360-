<html>

<body>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
<link rel="stylesheet" href="https://ebayoutsource.co.uk/assets/css/external/bootstrap-3-3-7.min.css">
<link rel="stylesheet" href="https://ebayoutsource.co.uk/assets/css/external/blue-light.css">
<link rel="stylesheet" href="https://ebayoutsource.co.uk/assets/css/external/slider.min.css">
<style>
	:root { --primary-color: #EB0000 !important; }
</style>
<div id="template-container">
	<nav class="navbar">
		<div class="container-fluid">
			<div class="row navbar-top">
				<div class="col-xs-12 col-md-6 navbar-header">
					<img class="logo img-fluid" alt="Brand" src="https://i.ebayimg.com/00/s/ODc4WDgxMg==/z/Ef8AAOSwzSNdx6zr/$_7.PNG" width="auto" height="120">
				</div>
				<div class="col-xs-12 col-md-6 navbar-best">
					<div class="col-md-6">
						<p><i class="fa fa-star"></i> UK Seller</p>
					</div>
					<div class="col-md-6">
						<p><i class="fa fa-truck"></i> Fast Shipping</p>
					</div>
					<div class="col-md-6">
						<p><i class="fa fa-thumbs-up"></i> Greater Service</p>
					</div>
					<div class="col-md-6">
						<p><i class="fa fa-heart"></i> Satisfaction Guarantee</p>
					</div>
				</div>
			</div>
			<div class="row menu">
				<div class="col-xs-12">
					<ul class="nav navbar-nav">
						<li><a class="text-uppercase" href="https://www.ebay.co.uk/sch/topbrandclearence/m.html?_nkw=&_armrs=1&_ipg=&_from=" target="_blank">Our Products</a>
						</li>
						<li><a class="text-uppercase" href="https://www.ebay.co.uk/usr/topbrandclearence" target="_blank">Like Our Page</a>
						</li>
						<li><a class="text-uppercase" href="https://www.ebay.co.uk/fdbk/feedback_profile/topbrandclearence?filter=feedback_page:All&_trksid=p2545226.m2531.l4585" target="_blank">Check Our Feedback</a>
						</li>
						<li><a class="text-uppercase" href="https://contact.ebay.co.uk/ws/eBayISAPI.dll?FindAnswers&requested=topbrandclearence&_trksid=p2545226.m2531.l4583&rt=nc" target="_blank">Contact Us</a>
						</li>
					</ul>
				</div>
			</div>
		</div>
	</nav>
	<div class="container-fluid bg-texture">
		<div class="row">
			<div class="col-xs-12 col-sm-10 col-sm-offset-1">
				<div class="col-xs-12"></div>
			</div>
		</div>
		<div class="row">
			<div class="col-xs-12 col-sm-7 col-sm-offset-1 ">
				<div class="col-xs-12 col-box">
					<div class="col-xs-12 mt-0">
						<h2 class="display-4">{{$name}}</h2>
					</div>
				</div>
				<div class="col-xs-12 col-box">
					<div class="col-xs-12 col-box-header">
						<h4 class="text-uppercase">gallery</h4>
					</div>
					<div class="col-xs-12 col-box-inside">
						<div id="gall">
							@isset($images[0])
								<input id="pic_0" name="switch" type="radio" checked>
								<label for="pic_0">
									<img src="{{$images[0]}}">
								</label>
								<img src="{{$images[0]}}">
							@endisset
							@isset($images[1])
								<input id="pic_1" name="switch" type="radio">
								<label for="pic_1">
									<img src="{{$images[1]}}">
								</label>
								<img src="{{$images[1]}}">
							@endisset
							@isset($images[2])
								<input id="pic_2" name="switch" type="radio">
								<label for="pic_2">
									<img src="{{$images[2]}}">
								</label>
								<img src="{{$images[2]}}">
							@endisset
							@isset($images[3])
								<input id="pic_3" name="switch" type="radio">
								<label for="pic_3">
									<img src="{{$images[3]}}">
								</label>
								<img src="{{$images[3]}}">
							@endisset
							@isset($images[4])
								<input id="pic_4" name="switch" type="radio">
								<label for="pic_4">
									<img src="{{$images[4]}}">
								</label>
								<img src="{{$images[4]}}">
							@endisset
						</div>
						<div class="line-break line-break-4"><span></span>
						</div>
						<div class="clearfix"><span></span>
						</div>
					</div>
				</div>
				<div class="col-xs-12 col-box">
					<div class="col-xs-12 col-box-header">
						<h4 class="text-uppercase">description</h4>
					</div>
					<div class="col-xs-12 col-box-inside">
						<p><span style="font-size: 14.4px;">{!! $description !!}</span>
							<br>
						</p>
					</div>
				</div>
				<div id="tab-section" class="col-xs-12 col-box col-box-tab">
					<div class="tab-box col-box-inside">
						<input id="tab1" type="radio" name="tabs" checked="" class="text-uppercase">
						<label for="tab1" class="text-uppercase"><i class="fa fas fa-credit-card" aria-hidden="true"></i> Payment</label>
						<input id="tab2" type="radio" name="tabs" class="text-uppercase">
						<label for="tab2" class="text-uppercase"><i class="fa fas fa-truck"></i> Delivery</label>
						<input id="tab3" type="radio" name="tabs" class="text-uppercase">
						<label for="tab3" class="text-uppercase"><i class="fa fas fa-sync"></i> Return Policy</label>
						<section id="content-1">
							<div class="animation opacity inner-box">We currently accept the following payment methods PayPal We do not accept paper cheques or postal orders. Payment must be received within 7 days. To ensure your purchase is protected by the eBay Protection Scheme it will only be delivered to your registered PayPal/ eBay address.
								<div class="box-logo">
									<img src="https://ebayoutsource.co.uk/assets/images/brands/paypal_logo.png">
									<img src="https://ebayoutsource.co.uk/assets/images/brands/visa_logo_small.png">
									<img src="https://ebayoutsource.co.uk/assets/images/brands/master_card_logo_small.png">
									<img src="https://ebayoutsource.co.uk/assets/images/brands/discover_logo_small.png">
									<img src="https://ebayoutsource.co.uk/assets/images/brands/american_express_logo_small.png">
								</div>
							</div>
						</section>
						<section id="content-2">
							<div class="animation opacity inner-box">
								<p><font face="Arial" size="4">All eligible items are dispatched through Royal Mail within 24 hours of receiving cleared funds. Items are carefully & professionally wrapped, so you receive your item in perfect condition. Items bought over the weekends and Bank Holidays will be dispatched on the 1st postal day. Items should be received within 2-3 working days. In the unlikely event that you do not receive your item within this time, please allow 10 working days for delivery before contacting us, as the Royal Mail do not consider an item lost before that time (15 days for international).</font>
									<br>
								</p>
							</div>
						</section>
						<section id="content-3">
							<div class="animation opacity inner-box">
								<p><span style="font-size: 14.4px;">In the event of Returns, Simply send it back to us within 14 days of receiving it in its original packaging, unused and unworn condition and we will issue a full refund once we receive the item(s). However, please contact us with the details if an exchange is needed and we will be more than happy to do so.</span>
									<br>
								</p>
							</div>
						</section>
					</div>
				</div>
				<div id="cross-section" class="col-xs-12 col-box">
					<div class="col-xs-12 col-box-header">
						<h4 class="text-uppercase"> Other Products </h4>
					</div>
					<div class="col-xs-12 col-box-inside">
						<div class="col-xs-12 col-sm-6 col-md-3">
							<img class="img-responsive" src="https://i.ebayimg.com/images/g/3mYAAOSw49BehctL/s-l1600.jpg">
							<h4>AJ ARMANI JEANS J08 1C Mens Denim Armani Jeans Stretch Regular Fit Cambodia Blue</h4><a class="button" target="_blank" href="https://www.ebay.co.uk/itm/254533085349">SEE</a>
						</div>
						<div class="col-xs-12 col-sm-6 col-md-3">
							<img class="img-responsive" src="https://i.ebayimg.com/images/g/6gAAAOSwHVFejcmy/s-l1600.jpg">
							<h4>ARMANI JEANS 922517 Womens Handbag Ladies Shoulder Strap Top Handle Bag</h4><a class="button" target="_blank" href="https://www.ebay.co.uk/itm/163876766386">SEE</a>
						</div>
						<div class="col-xs-12 col-sm-6 col-md-3">
							<img class="img-responsive" src="https://i.ebayimg.com/images/g/aF0AAOSwkTVei4BD/s-l1600.jpg">
							<h4>DIESEL JOPRAB BG16P Mens Trench Coat Virgin Wool Single Breasted Casual Overcoat</h4><a class="button" target="_blank" href="https://www.ebay.co.uk/itm/164107568599">SEE</a>
						</div>
						<div class="col-xs-12 col-sm-6 col-md-3">
							<img class="img-responsive" src="https://i.ebayimg.com/images/g/JqwAAOSw4O1ejJLr/s-l1600.jpg">
							<h4>DIESEL J-STREET Mens Biker Jacket Winter Bomber Outwear Casual Coat Red</h4><a class="button" target="_blank" href="https://www.ebay.co.uk/itm/163767244106">SEE</a>
						</div>
					</div>
				</div>
			</div>
			<div class="col-xs-12 col-sm-3">
				<div class="col-xs-12 col-box">
					<div class="col-xs-12 mt-0"></div>
				</div>
				<div class="col-xs-12 col-box">
					<div class="col-xs-12 col-box-header mt-3">
						<h4 class="text-uppercase text-center">feedback</h4>
					</div>
					<div class="col-xs-12 col-box-inside col-centered">
						<h3>500+</h3>
						<div class="col-feedback-stars"><i class="fa fas fa-star" aria-hidden="true"></i><i class="fa fas fa-star" aria-hidden="true"></i><i class="fas fas fa-star" aria-hidden="true"></i><i class="fa fas fa-star" aria-hidden="true"></i><i class="fa fas fa-star" aria-hidden="true"></i>
						</div>
						<h6 class="text-uppercase">positive comments</h6>
						<hr>
						<ul class="feedback-example-comment-list">
							<li><span class="buyer-id">e***n</span>: Great purchase and early delivery! Thank you ??????????</li>
							<li><span class="buyer-id">j***1</span>: Great item, perfect, arrived quickly thank you</li>
							<li><span class="buyer-id">1***j</span>: Thanks for a smooth transaction. Excellent Ebayer.</li>
							<li><span class="buyer-id">p***l</span>: Happy with item and service ??????????</li>
							<li><span class="buyer-id">0***m</span>: Highly Recommended seller, great product.</li>
							<li><span class="buyer-id">a***3</span>: Item arrived 8 days early. Item as stated. Well impressed.</li>
						</ul>
						<p><a href="https://feedback.ebay.co.uk/ws/eBayISAPI.dll?ViewFeedback2&userid=topbrandclearence" target="_blank">SEE ALL FEEDBACK</a>
						</p>
					</div>
				</div>
				<div class="col-xs-12 col-box">
					<div class="col-xs-12 col-box-header">
						<h4 class="text-uppercase text-center"> Delivery</h4>
					</div>
					<div class="col-xs-12 col-box-inside ">
						<div class="delivery-logos-box">
							<img src="https://ebayoutsource.co.uk/assets/images/brands/USPS-logo-small.png">
							<img src="https://ebayoutsource.co.uk/assets/images/brands/ups_logo_small.png">
							<img src="https://ebayoutsource.co.uk/assets/images/brands/deutsche_post_logo_small.png">
							<img src="https://ebayoutsource.co.uk/assets/images/brands/gls_logo_small.png">
							<img src="https://ebayoutsource.co.uk/assets/images/brands/australia_post_logo_small.png">
							<img src="https://ebayoutsource.co.uk/assets/images/brands/logo-royal-mail.png">
						</div>
						<ul class="delivery-list-payment"></ul>
					</div>
				</div>
				<div id="col-why-us" class="col-xs-12 col-box">
					<div class="col-xs-12 col-box-header">
						<h4 class="text-uppercase text-center">Why us</h4>
					</div>
					<div class="col-xs-12 col-box-inside">
						<p><span style="font-size: 14.4px;">Big Brands at Bigger Discounts! We are committed to excellent customer service!</span>
							<br>
						</p>
					</div>
				</div>
				<div class="col-xs-12 col-box">
					<div class="col-xs-12 col-box-header">
						<h4 class="text-uppercase text-center">Category</h4>
					</div>
					<div class="col-xs-12 col-box-inside category-box">
						<ul>
							<li><a href="https://www.ebaystores.co.uk/Top-Brand-Clearance-UK/All-Brands-/_i.html?_fsub=25991880010&_sid=753612360&_trksid=p4634.c0.m322" target="_blank">Featured Brands</a>
							</li>
							<li><a href="https://www.ebaystores.co.uk/Top-Brand-Clearance-UK/Mens-/_i.html?_fsub=26087351010&_sid=753612360&_trksid=p4634.c0.m322" target="_blank">Shop For Men</a>
							</li>
							<li><a href="https://www.ebaystores.co.uk/Top-Brand-Clearance-UK/Womens-/_i.html?_fsub=26087352010&_sid=753612360&_trksid=p4634.c0.m322" target="_blank">Shop For Women</a>
							</li>
							<li><a href="https://www.ebaystores.co.uk/Top-Brand-Clearance-UK/Kids-/_i.html?_fsub=26087353010&_sid=753612360&_trksid=p4634.c0.m322" target="_blank">Shop For Kids</a>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="container-fluid container-footer">
		<footer>
			<div class="row">
				<div class="col-xs-12">
					<div class="col-xs-12 col-md-4">
						<h3 class="text-uppercase">About us</h3>
						<p>topbrandclearanceuk  is a leading supplier of consumer goods and we pride ourselves on our excellent customer service and for providing a wide range of high-quality goods at affordable prices. Big Brands at Bigger Discounts! We are committed to excellent customer service!
							<br>
						</p>
					</div>
					<div class="col-xs-12 col-md-4">
						<h3 class="text-uppercase">Benefits</h3>
						<ul class="delivery-list-payment benefits-list-payment">
							<li>Only High Product Quality</li>
							<li>Value For Money</li>
							<li>Shipping with Royal Mail</li>
							<li>Original Product Guaranteed</li>
						</ul>
					</div>
					<div class="col-xs-12 col-md-4 footer-uselink-box">
						<h3 class="text-uppercase">Useful Links</h3>
						<ul>
							<li><a target="_blank" class="text-uppercase" href="https://www.ebay.co.uk/usr/topbrandclearence">Returns</a>
							</li>
							<li><a target="_blank" class="text-uppercase" href="https://www.ebay.co.uk/fdbk/feedback_profile/topbrandclearence?filter=feedback_page:All&_trksid=p2545226.m2531.l4585">Feedback</a>
							</li>
							<li><a target="_blank" class="text-uppercase" href="https://www.ebay.co.uk/usr/topbrandclearence">Business Details</a>
							</li>
						</ul>
					</div>
				</div>
			</div>
			<div class="row ">
				<div class="col-md-8 col-md-offset-2 col-footer-copy">
					<p class="text-uppercase footer-last-p">Copyright © 2020 topbrandclearanceuk | Template by
						<a href="https://www.ebay.com/str/combosoft" target="_blank"></a>
					</p>
				</div>
			</div>
		</footer>
	</div>
</div>
</body>

</html>